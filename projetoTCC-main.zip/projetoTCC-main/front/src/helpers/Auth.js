export const getTypeUser = () => localStorage.getItem('typeUser');

export const isAdmin = () => getTypeUser() === 'admin';

export const isCommon = () => getTypeUser() === 'comum';

export const logout = () => {
    localStorage.clear();
};