import { useEffect, useState } from 'react';
import Style from '../Test_Componente/Test_Componente.module.css';
import { FaTrash as Trash } from "react-icons/fa";
import { MdAddBox as Add } from "react-icons/md";

function Test_Componente({ form, handleChange, ActionAdd, ActionRemove, setForm }) {

    const [trashEnabled, setTrashEnabled] = useState(false);

    const [visualInfo, setVisualInfo] = useState([]);

    const iconTrash = () => {

        const tests = form.Testes_Utilizados.filter(test => test.Testes_Utilizados !== null)

        if (tests.length > 1) {

            setTrashEnabled(true)
        }

        else {

            setTrashEnabled(false)
        }

    }; //(OK)

    const removeInfo = (ordem) => {

        setVisualInfo(prev => {

            const updated = { ...prev };

            delete updated[ordem];

            return updated;

        });
    };//(OK)

    const handleChangeForm = (e) => {

        setForm(prev => ({

            ...prev,

            observacao_Teste: e.target.value

        }))

    }; //(OK)

    const updatedInput = () => {

        form.Testes_Utilizados.map((test, index) => {

            if (test.Quantidade && test.Custo) {

                let total = test.Quantidade * test.Custo;

                setVisualInfo(prev => ({

                    ...prev,

                    [index]: {

                        ...prev[index],

                        totalCost: parseFloat(total.toFixed(6))
                    }

                }))

            }

        })

    }//(OK)

    useEffect(() => {

        const totalSum = Object.values(visualInfo).reduce((acc, item) => acc + (item.totalCost || 0), 0);

        setForm(prev => ({

            ...prev,

            custo_total_Teste: totalSum == 0 ? totalSum.toFixed(6) : totalSum

        }));


    }, [visualInfo]); //(OK)

    useEffect(() => {

        updatedInput()

    }, [])

    useEffect(() => {

        iconTrash();

    }, [form.Testes_Utilizados]); //(OK)

    return (

        <div className={Style.body}>

            <h4>4. Custos Adicionais (NÃO INCLUSO NO CUSTO)</h4>
            <div className={Style.form}>

                <ul className={Style.label}>

                    <li className={Style.liDescription}>Descrição</li>
                    <li className={Style.defaultLi}>Quantidade</li>
                    <li className={Style.defaultLi}>Custo R$</li>
                    <li className={Style.defaultLi}>Custo Total R$</li>
                    <li className={Style.space}></li>

                </ul>
                <div className={Style.main}>

                    {form.Testes_Utilizados.map((test, index) => {

                        const totalCost = () => {

                            if (test.Quantidade && test.Custo) {

                                let total = test.Quantidade * test.Custo;

                                setVisualInfo(prev => ({

                                    ...prev,

                                    [index]: {

                                        ...prev[index],

                                        totalCost: parseFloat(total.toFixed(6))
                                    }

                                }))

                            }

                        };

                        if (test.Descricao_Test !== null) {

                            const totalCost = () => {

                                if (test.Quantidade && test.Custo) {

                                    let total = test.Quantidade * test.Custo;

                                    setVisualInfo(prev => ({

                                        ...prev,

                                        [index]: {

                                            ...prev[index],

                                            totalCost: parseFloat(total.toFixed(6))
                                        }

                                    }))

                                }

                            }

                            const clearTest = (e) => {

                                if (e.target.value.trim() == '') {

                                    setVisualInfo(prev => ({

                                        ...prev,

                                        [index]: {

                                            ...prev[index],

                                            totalCost: ''
                                        }

                                    }));

                                    test.Custo = '';

                                    test.Quantidade = '';

                                }

                            }

                            return (

                                <div className={Style.listDataMP} key={index}>

                                    <input
                                        className={`${Style.inputDescription} ${Style.default}`}
                                        id={index}
                                        name='Descricao_Test'
                                        value={test.Descricao_Test}
                                        onChange={(e) => { handleChange(e) }}
                                        onBlur={(e) => { clearTest(e) }}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.default}`}
                                        id={index}
                                        name='Quantidade'
                                        type='number'
                                        min={0}
                                        value={test.Quantidade}
                                        onChange={(e) => { handleChange(e) }}
                                        onBlur={() => { totalCost() }}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.default}`}
                                        id={index}
                                        name='Custo'
                                        type='number'
                                        min={0}
                                        value={test.Custo}
                                        onChange={(e) => { handleChange(e); totalCost() }}
                                        onBlur={() => { totalCost() }}

                                    />

                                    <input
                                        className={`${Style.inputDefault} ${Style.readOnly}`}
                                        readOnly
                                        value={visualInfo[index]?.totalCost}
                                    />
                                    <div className={Style.icon}>

                                        {trashEnabled &&

                                            <Trash onClick={() => { ActionRemove(index); removeInfo(index) }} />

                                        }

                                    </div>

                                </div>

                            );
                        };

                    })}

                    <div className={Style.iconAdd}>

                        <Add onClick={() => { ActionAdd() }} />

                    </div>

                </div>
                <div className={Style.footer}>

                    <div className={Style.observation}>

                        <h5>Obs:</h5>
                        <input
                            value={form.observacao_Teste}
                            onChange={(e) => { handleChangeForm(e) }}
                        />

                    </div>
                    <div className={Style.tax}>

                        <h5>Custo de Insumos / Consumíveis</h5>
                        <input readOnly value={form.custo_total_Teste} />

                    </div>

                </div>

            </div>

        </div>
    );
};

export default Test_Componente;