import Style from '../Form/Form.module.css'
import { TiHome as Home } from "react-icons/ti";
import { HiOutlineSave as Save } from "react-icons/hi";
import { AiFillFilePdf as PDF } from "react-icons/ai";
import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import html2pdf from 'html2pdf.js';
import MP_Componente from './MP_Componente/MP_Componente';
import MQ_Componente from './MQ_Componente/MQ_Componente';
import Fer_Componente from './Fer_Componente/Fer_Componente';
import Test_Componente from './Test_Componente/Test_Componente';
import api from '../../../../axiosConfig';

function Form({ orc }) {

    const id_user = localStorage.getItem("id_user");

    const name_user = localStorage.getItem("name");

    const department = localStorage.getItem("department");

    const [form, setForm] = useState({

        id_orcamento: orc.id_orcamento || null,
        cod_cliente: orc.cod_cliente || null,
        nome_do_cliente: orc.nome_do_cliente || null,
        tipo: orc.tipo || 'RCA',
        codigo: orc.codigo || null,
        versao_item: orc.versao_item || null,
        planta: orc.planta || 1,
        data: new Date().toISOString().split('T')[0],
        descricao: orc.descricao || null,
        codigo_desenho: orc.codigo_desenho || null,
        unidade: orc.unidade || 'PC',
        comprimento: orc.comprimento || null,
        largura: orc.largura || null,
        espessura: orc.espessura || null,
        tipo_vlm: orc.tipo_vlm || 'Cliente',
        volume_mes: orc.volume_mes || null,
        custo_total_MP: orc.custo_total_MP || null,
        observacao_MP: orc.observacao_MP || null,
        custo_total_MQ: orc.custo_total_MQ || null,
        observacao_MQ: orc.observacao_MQ || null,
        custo_total_Ferramenta: orc.custo_total_Ferramenta || null,
        observacao_Ferramenta: orc.observacao_Ferramenta || null,
        custo_total_Teste: orc.custo_total_Teste || null,
        observacao_Teste: orc.observacao_Teste || null,
        custo_total_Proc: orc.custo_total_Proc || null,
        scrap: orc.scrap || 4,
        CT_Proc_C_Scrap: orc.CT_Proc_C_Scrap || null,
        icms_considerado: orc.icms_considerado || 18,
        pis_considerado: orc.pis_considerado || 1.65,
        confins_considerado: orc.confins_considerado || 7.60,
        custo_fixo: orc.custo_fixo || 12,
        despesas_gerais: orc.despesas_gerais || 10,
        custo_financeiro: orc.custo_financeiro || 5,
        frete: orc.frete || 10,
        margem: orc.margem || 20,
        preco_final_s_imposto: orc.preco_final_s_imposto || null,
        preco_final_c_imposto: orc.preco_final_c_imposto || null,
        lta: orc.lta || null,
        bussines_link: orc.bussines_link || null,
        custo_adicional: orc.custo_adicional || null,
        department: department,
        orcamentista: id_user,
        MP_Utilizada: orc.MP_Utilizada || [

            {
                ID: null,
                Codigo_MP: null,
                Ordem: 1,
                Quantidade: null,
                Preco_Considerado: null,
            }

        ],
        Maquinas_Utilizadas: orc.Maquinas_Utilizadas || [

            {
                ID_Proc: null,
                Codigo_Maquina: null,
                Ordem: 1,
                Descricao_Operacao: null,
                Unidade_Operacao: null,
                Qtd_Por_Operecao: null,
                Pecas_Hora: null,
                Taxa_Hora_Considerada: null
            },



        ],
        Ferramentas_Utilizadas: orc.Ferramentas_Utilizadas || [

            {
                id: null,
                Codigo_Ferramenta: '',
                Descricao_Ferramenta: null,
                Quantidade: null,
                Custo: null,
                Diluicao_Meses: null,
                Diluicao_Pecas: null

            }

        ],
        Testes_Utilizados: orc.Testes_Utilizados || [

            {
                ID: null,
                Descricao_Test: '',
                Quantidade: null,
                Custo: null,
            }
        ],

    });

    const [message, setMessage] = useState(null);

    const plant = {

        1: 'Matriz',
        2: 'LP',
        5: 'Paraíba',

    };

    const [markUp, setMarkUp] = useState({

        value: null,
        factor: null

    });

    const [tax, setTax] = useState({

        value: null,
        factor: null
    });

    const navigate = useNavigate();

    const navigateToGet = () => {

        navigate('/Orcamentos/Get')

    };

    const handleChange = (e) => {

        const { name, value } = e.target;

        const camposNumericos = [

            'comprimento', 'largura', 'espessura',
            'volume_mes', 'custo_total_MP', 'custo_total_MQ',
            'custo_total_Ferramenta', 'custo_total_Teste',
            'custo_total_Proc', 'scrap', 'CT_Proc_C_Scrap',
            'icms_considerado', 'pis_considerado', 'confins_considerado',
            'custo_fixo', 'despesas_gerais', 'custo_financeiro',
            'frete', 'margem', 'preco_final_s_imposto', 'preco_final_c_imposto',
            'lta', 'bussines_link', 'custo_adicional'

        ];

        const valorFinal = camposNumericos.includes(name) ? (value !== '' ? parseFloat(value.replace(',', '.')) : value) : value;

        setForm(prev => ({

            ...prev,

            [name]: valorFinal

        }))

    };

    const formatData = () => {

        const [ano, mes, dia] = form.data.split('-')

        return `${dia}/${mes}/${ano}`

    };

    const directCostCalc = () => {

        const processCost = parseFloat(form.custo_total_MP) + parseFloat(form.custo_total_MQ);

        setForm(prev => ({

            ...prev,

            custo_total_Proc: processCost.toFixed(6)

        }))

    };

    const markUpCalculation = () => {

        if (form.custo_fixo && form.despesas_gerais && form.custo_financeiro && form.frete && form.margem) {

            const markUp = form.custo_fixo + form.despesas_gerais + form.custo_financeiro + form.frete + form.margem;

            const factorMarkUp = 1 - (markUp / 100);

            setMarkUp(prev => ({

                ...prev,

                value: markUp,
                factor: factorMarkUp.toFixed(4)
            }))
        }

        else {

            setMarkUp(prev => ({

                ...prev,

                value: null,
                factor: null
            }))

        };

    };

    const taxCalculation = () => {

        if (form.icms_considerado && form.pis_considerado && form.confins_considerado) {

            const Tax = form.icms_considerado + form.pis_considerado + form.confins_considerado;

            const factorTax = 1 - (Tax / 100)

            setTax(prev => ({

                ...prev,

                value: Tax,
                factor: factorTax.toFixed(4)

            }))

        }

        else {

            setTax(prev => ({

                ...prev,

                value: null

            }))
        }

    };

    const scrapCalculation = () => {

        if (form.custo_total_Proc && form.scrap) {

            const totalProc = parseFloat(form.custo_total_Proc);

            const scrap = parseFloat(form.scrap) / 100;

            const costTool = parseFloat(form.custo_total_Ferramenta);

            const priceScrap = (totalProc + (totalProc * scrap)) + costTool;

            setForm(prev => ({

                ...prev,

                CT_Proc_C_Scrap: priceScrap.toFixed(6)

            }));

        }

        else {

            setForm(prev => ({

                ...prev,

                CT_Proc_C_Scrap: null

            }));

        }
    };

    const FPWithOutTax = () => {

        if (form.CT_Proc_C_Scrap && markUp.factor) {

            const FPWithOutTax = parseFloat(form.CT_Proc_C_Scrap) / parseFloat(markUp.factor);

            setForm(prev => ({

                ...prev,

                preco_final_s_imposto: FPWithOutTax.toFixed(6)

            }))

        }

    };

    const FPWithTax = () => {

        if (form.preco_final_s_imposto && tax.factor) {

            const FPWithTax = parseFloat(form.preco_final_s_imposto) / parseFloat(tax.factor);

            setForm(prev => ({

                ...prev,

                preco_final_c_imposto: FPWithTax.toFixed(6)

            }))

        }

    };

    const removeMP = (position) => {

        const MPs = form.MP_Utilizada.map(MP => {

            if (MP.Ordem === position) {

                return { ...MP, Ordem: null };

            }

            return MP;

        });

        setForm(prev => ({

            ...prev,

            MP_Utilizada: MPs

        }));

    };

    const addMP = () => {

        const notNull = form.MP_Utilizada.filter(mp => mp.Ordem !== null);

        const newRawMaterial = {

            ID: null,
            Codigo_MP: null,
            Ordem: notNull.length + 1,
            Quantidade: null,
            Preco_Considerado: null,

        };

        setForm(prev => ({

            ...prev,

            MP_Utilizada: [...prev.MP_Utilizada, newRawMaterial]

        }));

    };

    const handleRawMaterial = (e) => {

        setForm(prevForm => {

            const updatedMPs = prevForm.MP_Utilizada.map(mp => {

                if (Number(mp.Ordem) === Number(e.target.id)) {

                    const trueType = e.target.name == 'Quantidade' || e.target.name == 'Preco_Considerado'
                        ? (e.target.value.trim() !== '' ? parseFloat(e.target.value.replace(',', '.')) : e.target.value) : e.target.value

                    return { ...mp, [e.target.name]: trueType };

                }

                return mp;

            });

            return {

                ...prevForm,
                MP_Utilizada: updatedMPs
            };

        });


    };

    const removeMQ = (position) => {

        const MQs = form.Maquinas_Utilizadas.map(MQ => {

            if (MQ.Ordem === position) {

                return { ...MQ, Ordem: null };

            }

            return MQ;

        });

        setForm(prev => ({

            ...prev,

            Maquinas_Utilizadas: MQs

        }));

    };

    const addMQ = () => {

        const notNull = form.Maquinas_Utilizadas.filter(maq => maq.Ordem !== null);

        const newMachine = {

            ID_Proc: null,
            Codigo_Maquina: null,
            Ordem: notNull.length + 1,
            Descricao_Operacao: null,
            Unidade_Operacao: null,
            Qtd_Por_Operecao: null,
            Pecas_Hora: null,
            Taxa_Hora_Considerada: null,

        };

        setForm(prev => ({

            ...prev,

            Maquinas_Utilizadas: [...prev.Maquinas_Utilizadas, newMachine]

        }));

    };

    const handleMachine = (e) => {

        setForm(prevForm => {

            const updatedMQs = prevForm.Maquinas_Utilizadas.map(mq => {

                if (Number(mq.Ordem) === Number(e.target.id)) {

                    if (e.target.value !== '') {

                        let valueTrue = null;

                        if (e.target.name == 'Qtd_Por_Operecao' || e.target.name == 'Pecas_Hora' || e.target.name == 'Taxa_Hora_Considerada') {

                            valueTrue = parseFloat(e.target.value);

                        }

                        else {

                            valueTrue = e.target.value;
                        }

                        return {

                            ...mq,

                            [e.target.name]: valueTrue

                        };
                    }

                    else {

                        return {

                            ...mq,

                            [e.target.name]: ''

                        };
                    }

                }

                return mq;

            });

            return {

                ...prevForm,
                Maquinas_Utilizadas: updatedMQs
            };

        });

    };

    const removeFerr = (position) => {

        const Ferr = form.Ferramentas_Utilizadas.map((ferr, index) => {

            if (index === position) {

                return {

                    ...ferr,

                    Codigo_Ferramenta: null,
                    Descricao_Ferramenta: null,
                    Quantidade: null,
                    Custo: null,
                    Diluicao_Meses: null,
                    Diluicao_Pecas: null
                };

            }

            return ferr;

        });

        setForm(prev => ({

            ...prev,

            Ferramentas_Utilizadas: Ferr

        }));

    };

    const addFerr = () => {

        const newTool = {

            id: null,
            Codigo_Ferramenta: '',
            Descricao_Ferramenta: null,
            Quantidade: null,
            Custo: null,
            Diluicao_Meses: null,
            Diluicao_Pecas: null,

        };

        setForm(prev => ({

            ...prev,

            Ferramentas_Utilizadas: [...prev.Ferramentas_Utilizadas, newTool]

        }));

    };

    const handleTool = (e) => {

        const { id, name, value } = e.target;

        const updatedTools = form.Ferramentas_Utilizadas.map((tool, index) => {

            if (index == id) {

                const valueTrue = name == 'Codigo_Ferramenta' || name == 'Descricao_Ferramenta'
                    ? value : (value.trim() !== '' ? parseFloat(value) : value);

                return { ...tool, [name]: valueTrue }

            }

            return tool;

        })

        setForm(prev => ({

            ...prev,

            Ferramentas_Utilizadas: updatedTools

        }))

    };

    const dilutionParts = () => {

        const updatedTools = form.Ferramentas_Utilizadas.map((ferr) => {

            if (ferr.Diluicao_Meses && form.volume_mes) {

                const result = parseInt(form.volume_mes) * parseFloat(ferr.Diluicao_Meses);

                ferr.Diluicao_Pecas = result;

            }

            return ferr

        });

        setForm(prev => ({

            ...prev,

            Ferramentas_Utilizadas: updatedTools

        }));

    };

    const removeTest = (position) => {

        const newTests = form.Testes_Utilizados.map((test, index) => {

            if (index === position) {

                return {

                    ...test,

                    Descricao_Test: null,
                    Quantidade: null,
                    Custo: null,
                };

            }

            return test;

        });

        setForm(prev => ({

            ...prev,

            Testes_Utilizados: newTests

        }));

    };

    const addTest = () => {

        const newTest = {

            ID: null,
            Descricao_Test: '',
            Quantidade: null,
            Custo: null,

        };

        setForm(prev => ({

            ...prev,

            Testes_Utilizados: [...prev.Testes_Utilizados, newTest]

        }));

    };

    const handleTest = (e) => {

        const { id, name, value } = e.target;

        const updatedTests = form.Testes_Utilizados.map((test, index) => {

            if (index == id) {

                const valueTrue = name == 'Descricao_Test' ? value : parseFloat(value);

                return { ...test, [name]: valueTrue }

            }

            return test;

        })

        setForm(prev => ({

            ...prev,

            Testes_Utilizados: updatedTests

        }))

    };

    // Não funcionou

    // const contentRef = useRef(null);

    // const generatePDF = () => {

    //     const content = contentRef.current;

    //     // Encontra a div interna com scroll
    //     const scrollDiv = content.querySelector('.divInf');

    //     // Aplica as classes temporárias

    //     scrollDiv?.classList.add('pdf-export-mode');

    //     const options = {

    //         margin: [0, 0, 0, 0],
    //         filename: "orcamento.pdf",
    //         html2canvas: {

    //             scale: 5,
    //             useCORS: true

    //         },
    //         jsPDF: {
    //             unit: "mm",
    //             format: "a4",
    //             orientation: "portrait"
    //         }
    //     };

    //     html2pdf().set(options).from(content).save().then(() => {
    //         // Remove os estilos temporários
    //         scrollDiv?.classList.remove('pdf-export-mode');
    //     });
    // };

    const SaveOrc = () => {

        //Validando Campos Obrigátorios

        const notNullFields = [

            'nome_do_cliente', 'tipo', 'codigo', 'versao_item', 'planta', 'data',
            'unidade', 'comprimento', 'largura', 'espessura', 'volume_mes'

        ];

        let nullFields = [];

        Object.entries(form).map((field) => {

            if (notNullFields.includes(field[0])) {

                console.log(field)


                if (field[1].length == 0) {

                    nullFields.push(field[0]);
                }

            }

        });

        if (nullFields.length > 0) {

            setMessage(`Preencha os campos obrigatórios "*"`)

            return;

        }

        //Validando os items de utilizados

        const validatedMPs = form.MP_Utilizada.filter(mp => mp.ID !== null || mp.Ordem !== null);

        const validatedMQs = form.Maquinas_Utilizadas.filter(mq => mq.ID_Proc !== null || mq.Ordem !== null);

        const validatedFerr = form.Ferramentas_Utilizadas.filter(ferr => ferr.id !== null || ferr.Codigo_Ferramenta !== null || (ferr.Codigo_Ferramenta?.trim?.() || '') !== '');

        const validatedTest = form.Testes_Utilizados.filter(test => test.ID !== null || test.Descricao_Test !== null || (test.Descricao_Test?.trim?.() || '') !== '');

        const cleanedForm = {

            ...form,

            MP_Utilizada: validatedMPs,
            Maquinas_Utilizadas: validatedMQs,
            Ferramentas_Utilizadas: validatedFerr,
            Testes_Utilizados: validatedTest
        };

        try {

            if (cleanedForm.id_orcamento) {

                api.put(`/Orcamentos/Put/${cleanedForm.id_orcamento}`, cleanedForm);

            }

            else {

                api.post('/Orcamentos/Post', cleanedForm);
            }

            setMessage('Orçamento Salvo');

        } catch (err) {

            setMessage('Erro ao Salvar o Orçamento')

            console.log(err)
        }

    };

    // useEffect(() => {

    //     console.log(form)

    // }, [form])

    useEffect(() => {

        formatData();

    }, [form.data]);

    useEffect(() => {

        directCostCalc();

    }, [form.custo_total_MP, form.custo_total_MQ]);

    useEffect(() => {

        scrapCalculation();

    }, [form.custo_total_Proc, form.scrap, form.custo_total_Ferramenta]);

    useEffect(() => {

        FPWithOutTax();

    }, [form.CT_Proc_C_Scrap, markUp.factor]);

    useEffect(() => {

        FPWithTax();

    }, [form.preco_final_s_imposto, tax.factor]);

    useEffect(() => {

        markUpCalculation();

    }, [form.custo_fixo, form.despesas_gerais, form.custo_financeiro, form.frete, form.margem]);

    useEffect(() => {

        taxCalculation();

    }, [form.icms_considerado, form.pis_considerado, form.confins_considerado]);

    return (

        <div className={Style.body} >

            <div className={Style.header}>

                <Home className={Style.icon} onClick={() => { navigateToGet() }} />
                <h1>BreakDown de Custos</h1>
                <div>

                    <PDF className={Style.iconPDF} />
                    <Save className={Style.icon} onClick={() => { SaveOrc() }} />

                </div>

            </div>
            <div className={Style.main}>

                <div className={Style.divSup}> {/*(OK)*/}

                    <div className={Style.supplierCard}>

                        <div className={Style.supplierData}>

                            <ul>

                                <li>Cód. Planta</li>
                                <li>Nome Planta</li>

                            </ul>
                            <div className={Style.supplierDataDiv}>

                                <div>

                                    <select
                                        className={`${Style.selectDefault} ${Style.default}`}
                                        name='planta'
                                        value={form.planta}
                                        onChange={(e) => { handleChange(e) }}>

                                        <option value={1}>1</option>
                                        <option value={2}>2</option>
                                        <option value={5}>5</option>

                                    </select>

                                </div>
                                <input
                                    className={Style.readOnly}
                                    readOnly
                                    value={plant[form.planta]}
                                />

                            </div>

                        </div>
                        <div className={Style.customerData}>

                            <ul>

                                <li className={Style.CDataLiDefault}>Cód. do Cliente</li>
                                <li className={Style.CDataLiNameCustomer}>Nome do Cliente <span className={Style.Mandatory}>*</span></li>
                                <li className={Style.CDataLiDefault}>Tipo de Orc.</li>
                                <li className={Style.CDataLiDefault}>Código <span className={Style.Mandatory}>*</span></li>
                                <li className={Style.CDataLiDefault}>Versão <span className={Style.Mandatory}>*</span></li>
                                <li className={Style.CDataLiDefault}>Tipo Vlm.</li>
                                <li className={Style.CDataLiDefault}>Volume Mensal <span className={Style.Mandatory}>*</span></li>

                            </ul>
                            <div className={Style.CDataInputs}>

                                <input
                                    className={Style.CDataInputDefault}
                                    type='number'
                                    name='cod_cliente'
                                    value={form.cod_cliente}
                                    onChange={(e) => { handleChange(e) }}
                                />
                                <input
                                    className={Style.CDataInputName}
                                    maxLength={41}
                                    name='nome_do_cliente'
                                    value={form.nome_do_cliente}
                                    onChange={(e) => { handleChange(e) }}
                                />
                                <div>

                                    <select
                                        className={`${Style.selectDefault} ${Style.default}`}
                                        name='tipo'
                                        value={form.tipo}
                                        onChange={(e) => { handleChange(e) }}
                                    >

                                        <option value={'RCA'}>RCA</option>
                                        <option value={'MD'}>MD</option>
                                        <option value={'NB'}>NB</option>
                                        <option value={'PI'}>PI</option>

                                    </select>

                                </div>
                                <input
                                    className={Style.CDataInputDefault}
                                    type='number'
                                    name='codigo'
                                    maxLength={5}
                                    value={form.codigo}
                                    onChange={(e) => { handleChange(e) }}
                                />
                                <input
                                    className={Style.CDataInputDefault}
                                    maxLength={2}
                                    name='versao_item'
                                    value={form.versao_item}
                                    onChange={(e) => { handleChange(e) }}
                                />
                                <div>

                                    <select
                                        className={`${Style.selectVlm} ${Style.default}`}
                                        name='tipo_vlm'
                                        value={form.tipo_vlm}
                                        onChange={(e) => { handleChange(e) }}
                                    >

                                        <option value={'Cliente'}>Cliente</option>
                                        <option value={'Lote Minimo'}>Lote Minimo</option>

                                    </select>

                                </div>
                                <input
                                    className={Style.CDataInputDefault}
                                    name='volume_mes'
                                    value={form.volume_mes}
                                    onChange={(e) => { handleChange(e) }}
                                    onBlur={() => { dilutionParts() }}
                                />

                            </div>

                        </div>

                    </div>
                    <div className={Style.productDataCard}>

                        <h4>Dados do Produto</h4>
                        <div className={Style.productData}>

                            <ul>

                                <li className={Style.ProDataLiDescription}>Descrição da Peça</li>
                                <li className={Style.ProDataLiCodPart}>Cód. da Peça/Desenho</li>
                                <li className={Style.ProDataLiDefault}>Unidade</li>
                                <li className={Style.ProDataLiDefault}>Comprimento <span className={Style.Mandatory}>*</span></li>
                                <li className={Style.ProDataLiDefault}>Largura <span className={Style.Mandatory}>*</span></li>
                                <li className={Style.ProDataLiDefault}>Espessura <span className={Style.Mandatory}>*</span></li>

                            </ul>
                            <div className={Style.inputs}>

                                <input
                                    className={`${Style.default} ${Style.inputDescription}`}
                                    name='descricao'
                                    value={form.descricao}
                                    maxLength={60}
                                    onChange={(e) => { handleChange(e) }}
                                />
                                <input
                                    className={`${Style.default} ${Style.inputCodPart}`}
                                    name='codigo_desenho'
                                    value={form.codigo_desenho}
                                    maxLength={60}
                                    onChange={(e) => { handleChange(e) }} />
                                <div>

                                    <select
                                        className={`${Style.selectDefault} ${Style.default}`}
                                        name='unidade'
                                        value={form.unidade}
                                        onChange={(e) => { handleChange(e) }}>

                                        <option value={'PC'}>PC</option>
                                        <option value={'PL'}>PL</option>
                                        <option value={'MT'}>MT</option>
                                        <option value={'BO'}>BO</option>

                                    </select>

                                </div>
                                <input
                                    className={`${Style.default} ${Style.prodDataInput}`}
                                    name='comprimento'
                                    value={form.comprimento}
                                    onChange={(e) => { handleChange(e) }}
                                />
                                <input
                                    className={`${Style.default} ${Style.prodDataInput}`}
                                    name='largura'
                                    value={form.largura}
                                    onChange={(e) => { handleChange(e) }}
                                />
                                <input
                                    className={`${Style.default} ${Style.prodDataInput}`}
                                    name='espessura'
                                    value={form.espessura}
                                    onChange={(e) => { handleChange(e) }}
                                />

                            </div>

                        </div>

                    </div>

                </div>
                <div className={Style.divInf}> {/* Div com Overflow */}

                    <div className={Style.components}>

                        <MP_Componente
                            form={form}
                            setForm={setForm}
                            handleChange={handleRawMaterial}
                            ActionRemove={removeMP}
                            ActionAdd={addMP}
                            setMessage={setMessage}
                        />

                        <MQ_Componente
                            form={form}
                            setForm={setForm}
                            handleChange={handleMachine}
                            ActionRemove={removeMQ}
                            ActionAdd={addMQ}
                            setMessage={setMessage}
                        />

                        <Fer_Componente
                            form={form}
                            setForm={setForm}
                            handleChange={handleTool}
                            ActionRemove={removeFerr}
                            ActionAdd={addFerr}
                            setMessage={setMessage}
                            CalcDiluitionPart={dilutionParts}
                        />

                        <Test_Componente
                            form={form}
                            setForm={setForm}
                            handleChange={handleTest}
                            ActionRemove={removeTest}
                            ActionAdd={addTest}
                            setMessage={setMessage}
                        />

                    </div>
                    <div className={Style.finalParameters}>

                        <div className={Style.lastValues}>

                            <div className={Style.salesParameters}>

                                <div className={Style.markUp}>

                                    <h4>6. Mark-Up</h4>
                                    <div className={Style.mainMarkUp}>

                                        <ul>

                                            <li>Custos Fixos (%)</li>
                                            <li>Depesas Gerias (%)</li>
                                            <li>Custos Financeiros (%)</li>
                                            <li>Frete (%)</li>
                                            <li>Margem (%)</li>

                                        </ul>
                                        <div>

                                            <input
                                                name='custo_fixo'
                                                onChange={(e) => { handleChange(e) }}
                                                value={form.custo_fixo}
                                            />
                                            <input
                                                name='despesas_gerais'
                                                onChange={(e) => { handleChange(e) }}
                                                value={form.despesas_gerais}
                                            />
                                            <input
                                                name='custo_financeiro'
                                                onChange={(e) => { handleChange(e) }}
                                                value={form.custo_financeiro}
                                            />
                                            <input
                                                name='frete'
                                                onChange={(e) => { handleChange(e) }}
                                                value={form.frete}
                                            />
                                            <input
                                                name='margem'
                                                onChange={(e) => { handleChange(e) }}
                                                value={form.margem}
                                            />

                                        </div>

                                    </div>
                                    <div className={Style.totalMarkUp}>

                                        <h5>Total Mark-Up</h5>
                                        <input
                                            className={Style.readOnly}
                                            readOnly
                                            value={markUp.value}
                                        />

                                    </div>

                                </div>
                                <div className={Style.alingTax}>

                                    <div className={Style.tax}>

                                        <h4>7. Imposto</h4>
                                        <div className={Style.mainTax}>

                                            <ul>

                                                <li>ICMS (%)</li>
                                                <li>PIS (%)</li>
                                                <li>CONFINS (%)</li>

                                            </ul>
                                            <div>

                                                <input
                                                    name='icms_considerado'
                                                    onChange={(e) => { handleChange(e) }}
                                                    value={form.icms_considerado}
                                                />
                                                <input
                                                    name='pis_considerado'
                                                    onChange={(e) => { handleChange(e) }}
                                                    value={form.pis_considerado}
                                                />
                                                <input
                                                    name='confins_considerado'
                                                    onChange={(e) => { handleChange(e) }}
                                                    value={form.confins_considerado}
                                                />

                                            </div>

                                        </div>
                                        <div className={Style.totalTax}>

                                            <h5>Total Imposto</h5>
                                            <input
                                                className={Style.readOnly}
                                                readOnly
                                                value={tax.value}
                                            />

                                        </div>

                                    </div>
                                    <div className={Style.factors}>

                                        <div className={Style.alingTextFac}>

                                            <h5>Fator de Imposto</h5>
                                            <h5>Fator de Mark-UP</h5>

                                        </div>
                                        <div className={Style.inputsFac}>

                                            <input
                                                className={Style.readOnly}
                                                readOnly
                                                value={tax.factor}
                                            />
                                            <input
                                                className={Style.readOnly}
                                                readOnly
                                                value={markUp.factor}
                                            />

                                        </div>

                                    </div>

                                </div>

                            </div>
                            <div className={Style.finalPrice}>

                                <div className={Style.directCost}>

                                    <div className={Style.labelDirectC}>

                                        <div>

                                            <h5>Sub-Total Custo Direto</h5>

                                        </div>
                                        <div>

                                            <h5>Custo direto c/ scrap (%)</h5>
                                            <input
                                                name='scrap'
                                                onChange={(e) => { handleChange(e) }}
                                                value={form.scrap}
                                            />

                                        </div>

                                    </div>
                                    <div className={Style.inputsDirectC}>

                                        <input
                                            className={Style.readOnly}
                                            readOnly
                                            value={form.custo_total_Proc || 0}
                                        />
                                        <input
                                            className={Style.readOnly}
                                            readOnly
                                            value={form.CT_Proc_C_Scrap || 0}
                                        />

                                    </div>

                                </div>
                                <div className={Style.MarkUpCost}>

                                    <h5 className={Style.title}>Preço com Mark-Up</h5>
                                    <div className={Style.mainMarkUpCost}>

                                        <div className={Style.labelMarkC}>

                                            <h5>Preço Calculado Sem Imposto</h5>
                                            <h5>Preço Calculado Com Imposto</h5>

                                        </div>
                                        <div className={Style.inputsMarkC}>

                                            <input
                                                className={Style.readOnly}
                                                readOnly
                                                value={form.preco_final_s_imposto}
                                            />
                                            <input
                                                className={Style.readOnly}
                                                readOnly
                                                value={form.preco_final_c_imposto}
                                            />

                                        </div>


                                    </div>

                                </div>

                            </div>

                        </div>
                        <div className={Style.subscriptions}>

                            <div className={Style.elaboration}>

                                <ul>

                                    <li>Elaborado Por:</li>
                                    <li>Data:</li>
                                    <li>Aprovado Por:</li>
                                    <li>Data:</li>

                                </ul>
                                <div className={Style.alingInputsElab}>

                                    <input
                                        className={Style.readOnly}
                                        readOnly
                                        value={name_user}
                                    />
                                    <input
                                        className={Style.readOnly}
                                        readOnly
                                        value={formatData()}
                                    />
                                    <input className={Style.default} />
                                    <input className={Style.default} />

                                </div>

                            </div>
                            <div className={Style.validity}>

                                <ul>

                                    <li>Vigência de:</li>
                                    <li>Vigência de:</li>
                                    <li>Preço Negociado:</li>

                                </ul>
                                <div className={Style.alingInputsVal}>

                                    <input className={Style.default} />
                                    <input className={Style.default} />
                                    <input className={Style.default} />

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            {message &&

                <div className={Style.message}>

                    <p>{message}</p>

                    {message == 'Orçamento Salvo'

                        ? <button onClick={(e) => { e.preventDefault(); setMessage(''); navigate('/Orcamentos/Get') }}> OK </button>

                        : <button onClick={(e) => { e.preventDefault(); setMessage('') }}> OK </button>
                    }

                </div>
            }

        </div>

    );

}

export default Form;