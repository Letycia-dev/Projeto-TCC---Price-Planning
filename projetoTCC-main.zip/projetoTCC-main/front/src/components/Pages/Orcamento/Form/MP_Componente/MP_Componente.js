import { useEffect, useState } from 'react';
import Style from '../MP_Componente/MP_Componente.module.css';
import { FaTrash as Trash } from "react-icons/fa";
import { MdAddBox as Add } from "react-icons/md";
import api from '../../../../../axiosConfig.js';

function MP_Componente({ form, handleChange, ActionAdd, ActionRemove, setForm, setMessage }) {

    const [trashEnabled, setTrashEnabled] = useState(false);

    const [visualInfo, setVisualInfo] = useState([]);

    const iconTrash = () => {

        const mps = form.MP_Utilizada.filter(mp => mp.Ordem !== null)

        if (mps.length > 1) {

            setTrashEnabled(true)
        }

        else {

            setTrashEnabled(false)
        }

    };

    const revomeInfo = (ordem) => {

        setVisualInfo(prev => {

            const updated = { ...prev };

            delete updated[ordem];

            return updated;

        });

    };

    const handleChangeForm = (e) => {

        setForm(prev => ({

            ...prev,

            observacao_MP: e.target.value

        }))

    };

    const updatedInput = () => {

        form.MP_Utilizada.map(async (mp) => {

            if (mp.Codigo_MP) {

                try {

                    const response = await api.get(`http://localhost:3333/Materia_prima/Get/AutoFill/${mp.Codigo_MP}`)

                    const dataMP = response.data.message;

                    const date = new Date(dataMP[0].dt_ultimo_custo).toISOString().split('T')[0];

                    const [ano, mes, dia] = date.split('-');

                    setVisualInfo(prev => ({

                        ...prev,

                        [mp.Ordem]: {

                            descricao: dataMP[0].descricao,
                            unidade: dataMP[0].unid_medida,
                            dataCusto: `${dia}/${mes}/${ano}`
                        }

                    }))

                } catch (err) {

                    setVisualInfo(prev => ({

                        ...prev,

                        [mp.Ordem]: {

                            descricao: '',
                            unidade: '',
                            dataCusto: '',
                            totalCost: null
                        }

                    }))

                    setMessage('Matéria-Prima não encontrada ou desabilitada')

                }
            }

            if (mp.Quantidade && mp.Preco_Considerado) {

                const total = parseFloat(mp.Quantidade) * parseFloat(mp.Preco_Considerado);

                setVisualInfo(prev => ({

                    ...prev,

                    [mp.Ordem]: { ...prev[mp.Ordem], totalCost: parseFloat(total.toFixed(6)) }

                }))

            }

            else {

                setVisualInfo(prev => ({

                    ...prev,

                    [mp.Ordem]: { ...prev[mp.Ordem], totalCost: 0 }

                }))
            }


        });

    };

    useEffect(() => {

        updatedInput()

    }, []);

    useEffect(() => {

        const totalSum = Object.values(visualInfo).reduce((acc, item) => acc + (item.totalCost || 0), 0);

        setForm(prev => ({

            ...prev,

            custo_total_MP: totalSum.toFixed(6)

        }));

        // console.log(visualInfo)

    }, [visualInfo, form.MP_Utilizada])

    useEffect(() => {

        //Conferindo se o MP está certo
        // console.log(form.MP_Utilizada)

        iconTrash();

    }, [form.MP_Utilizada]);

    return (

        <div className={Style.body}>

            <h4>1. Matéria-Prima / Serviço / Comp. Terceiros</h4>
            <div className={Style.form}>

                <ul className={Style.label}>

                    <li className={Style.defaultLi}>Código</li>
                    <li className={Style.liDescription}>Descrição de Máteria-Prima</li>
                    <li className={Style.defaultLi}>Unidade</li>
                    <li className={Style.defaultLi}>Qtd. Por PÇ</li>
                    <li className={Style.defaultLi}>Custo FOB</li>
                    <li className={Style.defaultLi}>Data IN</li>
                    <li className={Style.defaultLi}>Custo Total R$</li>
                    <li className={Style.space}></li>

                </ul>
                <div className={Style.main}>

                    {form.MP_Utilizada.map((mp) => {

                        const dataMP = async () => {

                            try {

                                const response = await api.get(`http://localhost:3333/Materia_prima/Get/AutoFill/${mp.Codigo_MP}`)

                                const dataMP = response.data.message;

                                const date = new Date(dataMP[0].dt_ultimo_custo).toISOString().split('T')[0];

                                const [ano, mes, dia] = date.split('-');

                                setVisualInfo(prev => ({

                                    ...prev,

                                    [mp.Ordem]: {

                                        descricao: dataMP[0].descricao,
                                        unidade: dataMP[0].unid_medida,
                                        dataCusto: `${dia}/${mes}/${ano}`
                                    }

                                }))

                                mp.Preco_Considerado = dataMP[0].preco_s_imposto;

                            } catch (err) {

                                setVisualInfo(prev => ({

                                    ...prev,

                                    [mp.Ordem]: {

                                        descricao: '',
                                        unidade: '',
                                        dataCusto: '',
                                        totalCost: null
                                    }

                                }))

                                mp.Preco_Considerado = '';

                                // setMessage('Matéria-Prima não encontrada ou desabilitada')

                            }

                        };

                        const totalCost = () => {

                            if (mp.Quantidade && mp.Preco_Considerado) {

                                const total = parseFloat(mp.Quantidade) * parseFloat(mp.Preco_Considerado);

                                setVisualInfo(prev => ({

                                    ...prev,

                                    [mp.Ordem]: { ...prev[mp.Ordem], totalCost: parseFloat(total.toFixed(6)) }

                                }))

                            }

                            else {

                                setVisualInfo(prev => ({

                                    ...prev,

                                    [mp.Ordem]: { ...prev[mp.Ordem], totalCost: 0 }

                                }))
                            }

                        };

                        if (mp.Ordem !== null) {

                            return (

                                <div className={Style.listDataMP} key={mp.Ordem}>

                                    <input
                                        className={`${Style.inputDefault} ${Style.default}`}
                                        id={mp.Ordem}
                                        name='Codigo_MP'
                                        value={mp.Codigo_MP}
                                        onChange={(e) => { handleChange(e); }}
                                        onBlur={() => { dataMP() }}
                                    />
                                    <input
                                        className={`${Style.inputDescription} ${Style.readOnly}`}
                                        readOnly
                                        value={visualInfo[mp.Ordem]?.descricao}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.readOnly}`}
                                        readOnly
                                        value={visualInfo[mp.Ordem]?.unidade}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.default}`}
                                        id={mp.Ordem}
                                        name='Quantidade'
                                        type='number'
                                        min={0}
                                        value={mp.Quantidade}
                                        onChange={(e) => { handleChange(e); }}
                                        onBlur={() => { totalCost() }}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.default}`}
                                        id={mp.Ordem}
                                        name='Preco_Considerado'
                                        type='number'
                                        min={0}
                                        value={mp.Preco_Considerado}
                                        onChange={(e) => { handleChange(e) }}
                                        onBlur={() => { totalCost() }}

                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.readOnly}`}
                                        readOnly
                                        value={visualInfo[mp.Ordem]?.dataCusto}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.readOnly}`}
                                        readOnly
                                        value={visualInfo[mp.Ordem]?.totalCost}
                                    />
                                    <div className={Style.icon}>

                                        {trashEnabled &&

                                            <Trash onClick={() => { ActionRemove(mp.Ordem); revomeInfo(mp.Ordem) }} />

                                        }

                                    </div>

                                </div>

                            );
                        };

                    })}

                    <div className={Style.iconAdd}>

                        <Add onClick={() => { ActionAdd() }} />

                    </div>

                </div>
                <div className={Style.footer}>

                    <div className={Style.observation}>

                        <h5>Obs:</h5>
                        <input
                            onChange={(e) => { handleChangeForm(e) }}
                            value={form.observacao_MP || null}
                        />

                    </div>
                    <div className={Style.tax}>

                        <h5>Custo da Matéria-Prima sem Imposto</h5>
                        <input readOnly value={form.custo_total_MP} />

                    </div>

                </div>

            </div>

        </div>
    );
};

export default MP_Componente;