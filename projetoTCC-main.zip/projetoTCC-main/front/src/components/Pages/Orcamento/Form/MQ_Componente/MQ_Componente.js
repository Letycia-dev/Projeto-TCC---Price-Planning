import { useEffect, useState } from 'react';
import Style from '../MQ_Componente/MQ_Componente.module.css';
import { FaTrash as Trash } from "react-icons/fa";
import { MdAddBox as Add } from "react-icons/md";
import api from '../../../../../axiosConfig.js';

function MQ_Componente({ form, handleChange, ActionAdd, ActionRemove, setForm, setMessage }) {

    const [trashEnabled, setTrashEnabled] = useState(false);

    const [visualInfo, setVisualInfo] = useState([]);

    const [machines, setMachines] = useState([]);

    const iconTrash = () => {

        const mqs = form.Maquinas_Utilizadas.filter(mq => mq.Ordem !== null)

        if (mqs.length > 1) {

            setTrashEnabled(true)
        }

        else {

            setTrashEnabled(false)
        }

    };

    const handleChangeVisu = (e) => {

        if (visualInfo.length > 0) {

            setVisualInfo(prev => ({

                ...prev,

                [e.target.id]: {

                    ...prev[e.target.id],

                    descricao: e.target.value

                }

            }))

        }

        else {

            setVisualInfo({

                [e.target.id]: {

                    descricao: e.target.value

                }

            })
        }

    };

    const addDesc = (e) => {

        const { name, value, id } = e.target;

        const [codigo, _] = value.split(' ');


        setVisualInfo(prev => ({

            ...prev,

            [id]: {

                ...prev[id],

                descricao: value

            }

        }));

        handleChange({

            target: {

                id: id,
                name: name,
                value: parseInt(codigo)
            }
        });

    };

    const revomeInfo = (ordem) => {

        setVisualInfo(prev => {

            const updated = { ...prev };

            delete updated[ordem];

            return updated;

        });

    };

    const handleChangeForm = (e) => {

        setForm(prev => ({

            ...prev,

            observacao_MQ: e.target.value

        }))

    };

    const updatedInput = () => {

        form.Maquinas_Utilizadas.map(async (mq) => {

            machines.map((maq) => {

                if (mq.Codigo_Maquina == maq.Codigo_Maquina) {

                    handleChange({

                        target: {

                            id: mq.Ordem,
                            name: 'Unidade_Operacao',
                            value: maq.unidade
                        }
                    });

                    handleChange({

                        target: {

                            id: mq.Ordem,
                            name: 'Taxa_Hora_Considerada',
                            value: maq.taxa_hora
                        }
                    });

                    setVisualInfo(prev => ({

                        ...prev,

                        [mq.Ordem]: {

                            ...prev[mq.Ordem],
                            descricao: prev[mq.Ordem]?.descricao || `${maq.Codigo_Maquina} ${maq.descricao}`,
                            Pecas_Hora: parseInt(maq.pecas_hora)
                        }

                    }));

                    if (mq.Qtd_Por_Operecao) {

                        let piecesHour = null;

                        if (mq.Pecas_Hora) {

                            piecesHour = mq.Qtd_Por_Operecao * mq.Pecas_Hora;

                        }

                        else {

                            piecesHour = mq.Qtd_Por_Operecao * parseInt(maq.pecas_hora);

                        };

                        if (piecesHour <= 100000) {

                            handleChange({

                                target: {

                                    id: mq.Ordem,
                                    name: 'Pecas_Hora',
                                    value: piecesHour
                                }
                            });

                            const Cycles = 3600 / piecesHour;

                            const costProc = mq.Taxa_Hora_Considerada / piecesHour;

                            setVisualInfo(prev => ({

                                ...prev,

                                [mq.Ordem]: {

                                    ...prev[mq.Ordem],

                                    ciclos: Cycles.toFixed(1),
                                    totalCost: parseFloat(costProc.toFixed(6))
                                }

                            }));

                        }

                        else {

                            handleChange({

                                target: {

                                    id: mq.Ordem,
                                    name: 'Pecas_Hora',
                                    value: 100000
                                }
                            });

                            const Cycles = 3600 / 100000;

                            const costProc = mq.Taxa_Hora_Considerada / 100000;

                            setVisualInfo(prev => ({

                                ...prev,

                                [mq.Ordem]: {

                                    ...prev[mq.Ordem],

                                    ciclos: Cycles.toFixed(1),
                                    totalCost: parseFloat(costProc.toFixed(6))
                                }

                            }));

                        };

                    };
                }

            });



        });

    };

    useEffect(() => {

        const totalSum = Object.values(visualInfo).reduce((acc, item) => acc + (item.totalCost || 0), 0);

        setForm(prev => ({

            ...prev,

            custo_total_MQ: totalSum.toFixed(6)

        }));

        // console.log(visualInfo)

        // console.log(form.Maquinas_Utilizadas)

    }, [visualInfo, form.Maquinas_Utilizadas])

    useEffect(() => {

        //Conferindo se o MQ está certo
        // console.log(form.Maquinas_Utilizadas)

        iconTrash();

    }, [form.Maquinas_Utilizadas]);

    useEffect(() => {

        const changeMachines = async () => {

            try {

                const response = await api.get('/Orcamentos/Machines');

                const MQs = response.data.message;

                setMachines(MQs);
            }
            catch (err) {

                console.log(err)

                setMessage('Sem maquinas')

            }

        };

        changeMachines();

    }, []);

    useEffect(() => {

        updatedInput()

    }, [machines]);


    return (

        <div className={Style.body}>

            <h4>2. Custo de Transformação</h4>
            <div className={Style.form}>

                <ul className={Style.label}>

                    <li className={Style.liMaq}>Máquina</li>
                    <li className={Style.liDescription}>Descrição de Operação</li>
                    <li className={Style.defaultLi}>Quantidade</li>
                    <li className={Style.liUni}>Unidade</li>
                    <li className={Style.defaultLi}>Peças Hora</li>
                    <li className={Style.defaultLi}>Ciclos (Seg)</li>
                    <li className={Style.defaultLi}>Taxa Hora</li>
                    <li className={Style.defaultLi}>Custo Total R$</li>
                    <li className={Style.space}></li>

                </ul>
                <div className={Style.main}>

                    {form.Maquinas_Utilizadas.map((mq) => {

                        const AutoFill = (e) => {

                            const [codigo, _] = e.target.value.split(' ');

                            if (codigo.length > 0) {

                                machines.map((maq) => {

                                    if (maq.Codigo_Maquina == codigo) {

                                        handleChange({

                                            target: {

                                                id: mq.Ordem,
                                                name: 'Unidade_Operacao',
                                                value: maq.unidade
                                            }
                                        });

                                        handleChange({

                                            target: {

                                                id: mq.Ordem,
                                                name: 'Taxa_Hora_Considerada',
                                                value: maq.taxa_hora
                                            }
                                        });

                                        setVisualInfo(prev => ({

                                            ...prev,

                                            [mq.Ordem]: { ...prev[mq.Ordem], Pecas_Hora: parseInt(maq.pecas_hora) }

                                        }));

                                    }

                                });

                            }

                            else {

                                mq.Unidade_Operacao = '';
                                mq.Qtd_Por_Operecao = 0;
                                mq.Pecas_Hora = 0;
                                mq.Taxa_Hora_Considerada = 0;

                                setVisualInfo(prev => ({

                                    ...prev,

                                    [mq.Ordem]: {

                                        ...prev[mq.Ordem],

                                        Pecas_Hora: 0,
                                        ciclos: 0,
                                        totalCost: 0
                                    }

                                }));

                            }

                        };

                        if (mq.Ordem !== null) {

                            return (

                                <div className={Style.listDataMQ} key={mq.Ordem}>

                                    <input
                                        className={`${Style.inputMaq} ${Style.default}`}
                                        id={mq.Ordem}
                                        name='Codigo_Maquina'
                                        value={visualInfo[mq.Ordem]?.descricao}
                                        onChange={(e) => { handleChangeVisu(e) }}
                                        onBlur={(e) => { addDesc(e); AutoFill(e); updatedInput() }}
                                        list='Machines'
                                    />
                                    <datalist id='Machines'>

                                        {machines.map((mac) => (

                                            <option
                                                key={mac.Codigo_Maquina}
                                                value={`${mac.Codigo_Maquina} ${mac.descricao}`}
                                            />

                                        ))}

                                    </datalist>
                                    <input
                                        className={`${Style.inputDescription} ${Style.default}`}
                                        id={mq.Ordem}
                                        name='Descricao_Operacao'
                                        value={mq.Descricao_Operacao}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.default}`}
                                        id={mq.Ordem}
                                        name='Qtd_Por_Operecao'
                                        type='number'
                                        min={0}
                                        value={mq.Qtd_Por_Operecao == 0 ? '' : mq.Qtd_Por_Operecao}
                                        onChange={(e) => { handleChange(e) }}
                                        onBlur={() => { updatedInput(); }}
                                    />
                                    <input
                                        className={`${Style.inputUni} ${Style.default}`}
                                        id={mq.Ordem}
                                        name='Unidade_Operacao'
                                        value={mq.Unidade_Operacao}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.default}`}
                                        id={mq.Ordem}
                                        name='Pecas_Hora'
                                        type='number'
                                        min={0}
                                        value={mq.Pecas_Hora == 0 ? '' : mq.Pecas_Hora}
                                        onChange={(e) => { handleChange(e) }}
                                        onBlur={() => { updatedInput() }}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.readOnly}`}
                                        readOnly
                                        value={visualInfo[mq.Ordem]?.ciclos == 0 ? '' : visualInfo[mq.Ordem]?.ciclos}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.default}`}
                                        id={mq.Ordem}
                                        name='Taxa_Hora_Considerada'
                                        type='number'
                                        min={0}
                                        value={mq.Taxa_Hora_Considerada == 0 ? '' : mq.Taxa_Hora_Considerada}
                                        onChange={(e) => { handleChange(e) }}
                                        onBlur={() => { updatedInput() }}
                                    />
                                    <input
                                        className={`${Style.inputDefault} ${Style.readOnly}`}
                                        readOnly
                                        value={visualInfo[mq.Ordem]?.totalCost == 0 ? '' : visualInfo[mq.Ordem]?.totalCost}
                                    />
                                    <div className={Style.icon}>

                                        {trashEnabled &&

                                            <Trash onClick={() => { ActionRemove(mq.Ordem); revomeInfo(mq.Ordem) }} />

                                        }

                                    </div>

                                </div>

                            );
                        };

                    })}

                    <div className={Style.iconAdd}>

                        <Add onClick={() => { ActionAdd() }} />

                    </div>

                </div>
                <div className={Style.footer}>

                    <div className={Style.observation}>

                        <h5>Obs:</h5>
                        <input
                            value={form.observacao_MQ}
                            onChange={(e) => { handleChangeForm(e) }} />

                    </div>
                    <div className={Style.tax}>

                        <h5>Custo de Transformação</h5>
                        <input readOnly value={form.custo_total_MQ} />

                    </div>

                </div>

            </div>

        </div>
    );
};

export default MQ_Componente;