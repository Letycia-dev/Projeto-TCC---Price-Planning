import SideBar from '../../../Layout/Menu Latertal/MenuLateral.js';
import { useLocation } from 'react-router-dom';
import Style from "../Orcgeral.module.css";
import Form from "../Form/Form.js";


function Put() {

  const location = useLocation();

  const orc = location.state?.orc;

  return (

    <div className={Style.body}>

      <SideBar />

      <div className={Style.conteiner}>

        <Form orc={orc} />

      </div>

    </div>

  );

}

export default Put;