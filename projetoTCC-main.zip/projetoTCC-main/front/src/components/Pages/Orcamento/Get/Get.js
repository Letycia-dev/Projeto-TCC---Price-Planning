import { format } from 'date-fns';
import { useState, useEffect } from 'react';
import api from '../../../../axiosConfig';
import StyleGeneral from '../Orcgeral.module.css';
import Style from '../Get/Get.module.css';
import { IoSearchSharp as Lupa } from "react-icons/io5";
import { MdAddBox as Add } from "react-icons/md";
import { HiPencil as Pencil } from "react-icons/hi2";
import SiderBar from "../../../Layout/Menu Latertal/MenuLateral";
import { useNavigate } from "react-router-dom";
import { FaTrash as Trash } from "react-icons/fa";

const Get = () => {

  const type_user = localStorage.getItem('typeUser');

  const [dados, setDados] = useState([]);

  const [message, setMessage] = useState(null);

  const [tipoPesquisa, setTipoPesquisa] = useState('tipo');

  const [pesquisa, setPesquisa] = useState('');

  const [idDelete, setIdDelete] = useState(null);

  const plant = {

    1: 'Matriz',
    2: 'LP',
    5: 'Paraíba',

  };

  const navigate = useNavigate();

  const mudancaPesquisa = (e) => {

    setTipoPesquisa(e.target.value);

  };

  const ordenarDados = (dados, tipo) => {

    if (tipo === 'codigo') {

      return [...dados].sort((a, b) => a.codigo - b.codigo);

    }

    else {

      return [...dados].sort((a, b) => a[tipo].localeCompare(b[tipo]));

    };

  };

  const handleSearch = async () => {

    try {

      const response = await api.get('/Orcamentos/Get');

      let data = response.data;

      let resultado = data.filter(orc => orc.department == 'Engenharia');

      if (tipoPesquisa && pesquisa) {

        resultado = resultado.filter((item) => item[tipoPesquisa].toString().toLowerCase().includes(pesquisa.toLowerCase()));

      }

      else if (tipoPesquisa) {

        resultado = ordenarDados(resultado, tipoPesquisa);

      }

      setDados(resultado);

    }
    catch (error) {

      console.log(error)

      setDados([]);

    }

  };

  const navigateToPut = (dataOrc) => {

    console.log(dataOrc);

    navigate("/Orcamentos/Put", { state: { orc: dataOrc } });

  };

  const navigateToPost = () => {

    navigate("/Orcamentos/Post");

  };

  const confirmDelOrc = (id) => {

    if (type_user == 'Administrador') {

      setMessage('Deseja excluir o orçamento permanentemente?');

      setIdDelete(id);

    }

    else {

      setMessage('Ação permitida somente por Administradores')

    }

  };

  const deleteOrc = () => {

    try {

      api.delete(`Orcamentos/Delete/${idDelete}`);

      setMessage('Orçamento deletado');

    } catch (err) {

      setMessage('Não foi possivel deletar o orçamento');

      console.log(err);

    }

  }

  const roundNumber = (number) => {

    const num = parseFloat(number);

    if (isNaN(num)) return '0.000';

    return num.toFixed(3);

  };

  useEffect(() => {

    handleSearch();

  }, [dados]);

  return (

    <div className={StyleGeneral.body}>

      <SiderBar />

      <div className={StyleGeneral.conteiner}>

        <div className={Style.body}>

          <div className={Style.header}>

            <h2>Orçamentos Realizados</h2>

            <div className={Style.campo_add}>

              <div className={Style.pesquisar}>

                <label htmlFor="pesquisa">Campo</label>

                <select
                  className={Style.combo_box}
                  value={tipoPesquisa}
                  onChange={mudancaPesquisa}
                >

                  <option value={'tipo'}>Tipo</option>
                  <option value={'codigo'}>Código</option>
                  <option value={'nome_do_cliente'}>Cliente</option>
                  <option value={'orcamentista'}>Usúario</option>

                </select>

                <div className={Style.inputPesquisa}>

                  <input id="pesquisa"
                    type="text"
                    value={pesquisa}
                    onChange={(e) => setPesquisa(e.target.value)}
                    placeholder="Digite aqui..." />

                  <div className={Style.icone_pesquisa} onClick={handleSearch}>

                    <Lupa />

                  </div>

                </div>

              </div>

              <div className={Style.adicionar} onClick={navigateToPost}>

                <h4>Adicionar</h4>
                <Add className={Style.icone} />

              </div>

            </div>

          </div>
          <div className={Style.read}>

            <div className={Style.backgroundRead}>

              <ul className={Style.label}>

                <li className={Style.defaultLi}>Tipo</li>
                <li className={Style.defaultLi}>Código</li>
                <li className={Style.defaultLi}>Versão</li>
                <li className={Style.liDescriptionLabel}>Descrição</li>
                <li className={Style.defaultLi}>Cliente</li>
                <li className={Style.defaultLi}>DT. de Realização</li>
                <li className={Style.defaultLi}>Comprimento da Peça</li>
                <li className={Style.defaultLi}>Largura da Peça</li>
                <li className={Style.defaultLi}>Espessura da Peça</li>
                <li className={Style.defaultLi}>Volume Mês</li>
                <li className={Style.defaultLi}>Unidades</li>
                <li className={Style.defaultLi}>Planta</li>
                <li className={Style.defaultLi}>Custo das M.P's</li>
                <li className={Style.defaultLi}>Custo das Operações</li>
                <li className={Style.defaultLi}>Custo do Ferramental</li>
                <li className={Style.defaultLi}>Custo dos Testes</li>
                <li className={Style.defaultLi}>Preço Com Scrap</li>
                <li className={Style.defaultLi}>Preço Sem Imposto</li>
                <li className={Style.defaultLi}>Preço Com Imposto</li>
                <li className={Style.defaultLi}>Usuário</li>
                <li className={Style.spaceLi}></li>

              </ul>

              {dados.length > 0 ?

                dados.map((orc) => {

                  const Costdate = format(new Date(orc.data), 'dd/MM/yyyy');
                  const CTRawMaterial = roundNumber(orc.custo_total_MP);
                  const CTMachine = roundNumber(orc.custo_total_MQ);
                  const CTTool = roundNumber(orc.custo_total_Ferramenta);
                  const CTTest = roundNumber(orc.custo_total_Teste);
                  const CTProcessScrap = roundNumber(orc.CT_Proc_C_Scrap);
                  const FinalPriceNoTax = roundNumber(orc.preco_final_s_imposto);
                  const FinalPriceWithTax = roundNumber(orc.preco_final_c_imposto);

                  return (

                    <ul key={orc.codigo} className={Style.orcRegister}>

                      <li className={Style.defaultLiRegister}>{orc.tipo}</li>
                      <li className={Style.defaultLiRegister}>{orc.codigo}</li>
                      <li className={Style.defaultLiRegister}>{orc.versao_item}</li>
                      <li className={Style.liRegisterDescription}>{orc.descricao}</li>
                      <li
                        className={`${Style.defaultLiRegister} 
                                    ${orc.nome_do_cliente.length > 10 ? Style.alignStart : ''}`}
                      >

                        {orc.nome_do_cliente}

                      </li>
                      <li className={Style.defaultLiRegister}>{Costdate}</li>
                      <li className={Style.defaultLiRegister}>{orc.comprimento}</li>
                      <li className={Style.defaultLiRegister}>{orc.largura}</li>
                      <li className={Style.defaultLiRegister}>{orc.espessura}</li>
                      <li className={Style.defaultLiRegister}>{orc.volume_mes}</li>
                      <li className={Style.defaultLiRegister}>{orc.unidade}</li>
                      <li className={Style.defaultLiRegister}>{plant[orc.planta]}</li>
                      <li className={Style.defaultLiRegister}>{CTRawMaterial}</li>
                      <li className={Style.defaultLiRegister}>{CTMachine}</li>
                      <li className={Style.defaultLiRegister}>{CTTool}</li>
                      <li className={Style.defaultLiRegister}>{CTTest}</li>
                      <li className={Style.defaultLiRegister}>{CTProcessScrap}</li>
                      <li className={Style.defaultLiRegister}>{FinalPriceNoTax}</li>
                      <li className={Style.defaultLiRegister}>{FinalPriceWithTax}</li>
                      <li className={Style.defaultLiRegister}>{orc.orcamentista}</li>
                      <li className={Style.iconsOrc}>

                        <Pencil onClick={() => { navigateToPut(orc) }} />
                        <Trash onClick={() => { confirmDelOrc(orc.id_orcamento) }} />

                      </li>

                    </ul>

                  )

                })

                :

                <div className={Style.orcRegister}>

                  <p>Não há Aproveitamentos Salvos</p>

                </div>

              }

            </div>

          </div>

          {message &&

            <div className={Style.message}>

              <p>{message}</p>

              {message == 'Deseja excluir o orçamento permanentemente?'

                ? <div className={Style.alignBtns}>

                  <button onClick={(e) => { e.preventDefault(); setMessage(null); deleteOrc() }}> Sim </button>
                  <button onClick={(e) => { e.preventDefault(); setMessage(null); setIdDelete(null) }}> Não </button>

                </div>


                : <button onClick={(e) => { e.preventDefault(); setMessage(null) }}> OK </button>


              }

            </div>
          }

        </div>

      </div>

    </div>
  );

};
export default Get;