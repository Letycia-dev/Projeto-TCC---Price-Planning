import Style from "../Orcgeral.module.css";
import SideBar from '../../../Layout/Menu Latertal/MenuLateral.js';
import Form from "../Form/Form.js";

function Post() {

  return (

    <div className={Style.body}>

      <SideBar />

      <div className={Style.conteiner}>

        <Form orc={''} />

      </div>

    </div>
    
  );
}

export default Post;