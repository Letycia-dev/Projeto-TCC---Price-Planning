import Form from '../FormUsuarios/Form.js';
import SideBar from '../../../Layout/Menu Latertal/MenuLateral.js';
import Style from '../UserGeral.module.css';

function Post() {
    return (
        <div className={Style.body}>
            <SideBar />
            <div className={Style.conteiner}>
                <Form
                    title={'Cadastro de Usuário'}
                    nameButton={'Cadastrar'}
                    user={''}
                />
            </div>
        </div>
    );
}

export default Post;