import { useEffect, useState } from "react";
import api from "../../../../axiosConfig";
import Style from "../Get/Get.module.css";
import { IoSearchSharp as Lupa } from "react-icons/io5";
import { MdAddBox as Add } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import SiderBar from "../../../Layout/Menu Latertal/MenuLateral";
import StyleGeneral from "../UserGeral.module.css";
import { HiPencil as Pencil } from "react-icons/hi2";

const Get = () => {

  const [dados, setDados] = useState([]);

  const typeUser = localStorage.getItem("typeUser");

  const [tipoPesquisa, setTipoPesquisa] = useState("id_user");

  const [pesquisa, setPesquisa] = useState("");

  const [message, setMessage] = useState('');

  const navigate = useNavigate();

  const mudançaPesquisa = (e) => {

    setTipoPesquisa(e.target.value);

  };

  const ordenarDados = (dados, tipo) => {

    if (tipo === "id_user" || tipo === 'Enabled') {

      return [...dados].sort((a, b) => a.id - b.id);

    }

    else if (tipo === "name" || tipo === "typeUser") {

      return [...dados].sort((a, b) => a[tipo].localeCompare(b[tipo]));

    }

    return dados;
  };

  const handleSearch = async () => {

    let url = "http://localhost:3333/Usuario/Get";

    try {

      const response = await api.get(url);

      let resultado = response.data;

      if (tipoPesquisa && pesquisa) {

        if (tipoPesquisa === "Enabled") {

          if (pesquisa.toUpperCase().includes("SIM") && pesquisa.length === 3) {

            resultado = resultado.filter((item) =>

              item[tipoPesquisa].toString().toLowerCase().includes(1)

            );

          }

          if (pesquisa.toUpperCase().includes("NÃO") || pesquisa.toUpperCase().includes("NAO") && pesquisa.length === 3) {

            resultado = resultado.filter((item) =>

              item[tipoPesquisa].toString().toLowerCase().includes(0)

            );

          }

        }

        else {

          resultado = resultado.filter((item) =>

            item[tipoPesquisa].toString().toLowerCase().includes(pesquisa.toLowerCase())

          );

        }

      }

      else if (tipoPesquisa) {

        resultado = ordenarDados(resultado, tipoPesquisa);

      }

      setDados(resultado);

    } catch (error) {

      console.log(error);

      setDados('');
    }

  };

  const navigateToPut = (userData) => {

    if (typeUser == 'Administrador') {

      navigate("/Usuario/Put", { state: { user: userData } });

    }

    else {

      setMessage("Ação permitida somente por administradores");

    }

  };

  const navigateToPost = () => {

    if (typeUser == 'Administrador') {

      navigate("/Usuario/Post");

    }

    else {

      setMessage("Ação permitida somente por administradores");

    }

  };

  useEffect(() => {

    handleSearch();

  }, [dados, pesquisa, tipoPesquisa]);

  return (

    <div className={StyleGeneral.body}>

      <SiderBar />

      <div className={StyleGeneral.conteiner}>

        <div className={Style.Body_GetMP}>

          <div className={Style.header}>

            <h2>Usuários</h2>

            <div className={Style.campo_add}>

              <div className={Style.pesquisar}>

                <label htmlFor="pesquisa">Campo</label>

                <select
                  className={Style.combo_box}
                  value={tipoPesquisa}
                  onChange={mudançaPesquisa}
                >

                  <option value={"id_user"}>ID</option>
                  <option value={"name"}>Nome</option>
                  <option value={"typeUser"}>TP. Usuario</option>
                  <option value={"Enabled"}>Habilitado</option>

                </select>

                <div className={Style.inputPesquisa}>

                  <input id="pesquisa"
                    type="text"
                    value={pesquisa}
                    onChange={(e) => setPesquisa(e.target.value)}
                    placeholder="Digite aqui..." />

                  <div className={Style.icone_pesquisa} onClick={handleSearch}>

                    <Lupa />

                  </div>

                </div>

              </div>

              <div className={Style.adicionar} onClick={() => {navigateToPost()}}>

                <h4>Adicionar</h4>
                <Add className={Style.icone_add} />

              </div>

            </div>

          </div>

          <div className={Style.read}>

            <ul className={Style.label}>

              <li className={Style.defaultLi}>ID</li>
              <li className={Style.defaultLi}>Nome</li>
              <li className={Style.defaultLi}>T.P. Usuário</li>
              <li className={Style.defaultLi}>Departamento</li>
              <li className={Style.defaultLi}>Habilitado</li>
              <li className={Style.spaceLi}></li>

            </ul>

            {dados ? (

              <>
                {dados.map((givenUser) => (

                  <ul key={givenUser.id_user} className={Style.userRegister}>

                    <li className={Style.defaultLiRegister}>{givenUser.id_user}</li>
                    <li className={Style.defaultLiRegister}>{givenUser.name}</li>
                    <li className={Style.defaultLiRegister}>{givenUser.typeUser}</li>
                    <li className={Style.defaultLiRegister}>{givenUser.department}</li>
                    <li className={Style.defaultLiRegister}>{givenUser.Enabled == 0 ? 'Não' : 'Sim'}</li>
                    <li className={Style.icons}>

                      <Pencil onClick={() => { navigateToPut(givenUser) }} />

                    </li>

                  </ul>

                ))}

              </>

            ) : (

              <div className={Style.userRegister}>

                <p>Dados não encontrados</p>

              </div>

            )}

          </div>

        </div>

      </div>

      {message &&

        <div className={Style.message}>

          <p>{message}</p>
          <button onClick={(e) => { e.preventDefault(); setMessage('') }}> OK </button>

        </div>
      }

    </div>

  )
};

export default Get;
