import Form from '../FormUsuarios/Form.js';
import SideBar from '../../../Layout/Menu Latertal/MenuLateral.js';
import Style from '../UserGeral.module.css';
import { useLocation } from 'react-router-dom';

function Put() {

    const location = useLocation();

    const user = location.state?.user;

    console.log(user)

    return (
        <div className={Style.body}>

            <SideBar />
            <div className={Style.conteiner}>

                <Form
                    title={'Atualização de Usuário'}
                    nameButton={'Atualizar'}
                    user={user}
                />

            </div>
        </div>
    );
}

export default Put;
