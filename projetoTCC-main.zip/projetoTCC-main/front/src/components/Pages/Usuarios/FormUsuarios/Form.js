import { TiHome as Home } from "react-icons/ti";
import { BsPerson as IconeUser } from 'react-icons/bs';
import { useNavigate } from "react-router-dom";
import { FaEye as VisiblePassword } from "react-icons/fa";
import { FaEyeSlash as HiddenPassword } from "react-icons/fa6";
import api from "../../../../axiosConfig";
import Style from './Form.module.css';
import { useEffect, useState } from "react";

function Form({ title, nameButton, user = {} }) {

    const [formData, setFormData] = useState({

        name: user.name || "",
        password: user.password || "",
        department: user.department || "",
        typeUser: user.typeUser || "",
        enabled: user.Enabled === 0 ? 0 : user.Enabled || ''

    });

    const [passwordV, setPasswordV] = useState(false);

    const [typePassword, setTypePassword] = useState('password');

    const [messageDataBase, setMessageDataBase] = useState('');

    const navigate = useNavigate();

    const handleChange = (e) => {

        const { name, value } = e.target;

        const data = name === "enabled" ? parseInt(value) : value;

        setFormData({ ...formData, [name]: data });

    };

    const togglePasswordVisibility = () => {

        setPasswordV(!passwordV);

        setTypePassword(passwordV ? 'password' : 'text');
    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        try {

            if (user.id_user) {

                await api.put(`http://localhost:3333/Usuario/Put/${user.id_user}`, formData);

                setMessageDataBase("Usuário atualizado com sucesso!");
            }

            else {

                await api.post("http://localhost:3333/Usuario/Post", formData);

                setMessageDataBase("Usuário cadastrado com sucesso!");

            }

            console.log(formData)

        }
        catch (error) {

            console.error("Erro ao salvar usuário:", error);

            setMessageDataBase("Não foi possivel salvar o usuario");

        }

    };

    // useEffect(() => {

    //     console.log(formData)

    // }, [formData])

    return (

        <div className={Style.body}>

            <div className={Style.header}>

                <Home className={Style.iconHome} onClick={() => { navigate('/Usuario/Get') }} />

                <h1>{title}</h1>

            </div>

            <div className={Style.main}>

                <div className={Style.backgroundForm}>

                    <div className={Style.iconUser}>

                        <IconeUser />

                    </div>

                    <form onSubmit={handleSubmit}>

                        <div className={Style.data}>

                            <div className={Style.given}>

                                <h3>Nome</h3>
                                <h3>Senha</h3>
                                <h3>Tipo</h3>
                                <h3>Departamento</h3>
                                {user ? <h3>Habilitado</h3> : <></>}

                            </div>

                            <div className={Style.given}>

                                <input className={Style.inputName}
                                    name="name"
                                    value={formData.name}
                                    onChange={handleChange}
                                    required />

                                <div className={Style.inputPassword}>

                                    <input type={typePassword}
                                        className={Style.inputDefault}
                                        name="password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required />

                                    {passwordV ? <VisiblePassword className={Style.icon} onClick={togglePasswordVisibility} />
                                        : <HiddenPassword className={Style.icon} onClick={togglePasswordVisibility} />}

                                </div>

                                <select
                                    className={`${Style.inputDefault} ${Style.select}`}
                                    name="typeUser"
                                    value={formData.typeUser}
                                    onChange={handleChange}
                                    required
                                >

                                    <option value={''}></option>
                                    <option value={'Comum'}>Comum</option>
                                    <option value={'Administrador'}>Administrador</option>

                                </select>

                                <select
                                    className={`${Style.inputDefault} ${Style.select}`}
                                    name="department"
                                    value={formData.department}
                                    onChange={handleChange}
                                    required
                                >

                                    <option value={''}></option>
                                    <option value={'Engenharia'}>Engenharia</option>
                                    <option value={'Vendas'}>Vendas</option>

                                </select>

                                {user ?

                                    <div className={Style.checkBox}>

                                        <div className={Style.enabledInput}>

                                            <p>Sim</p>
                                            <input
                                                type="checkbox"
                                                name="enabled"
                                                value={1}
                                                checked={formData.enabled === 1}
                                                onChange={handleChange}
                                            />

                                        </div>
                                        <div className={Style.enabledInput}>

                                            <p>Não</p>
                                            <input
                                                type="checkbox"
                                                name="enabled"
                                                value={0}
                                                checked={formData.enabled === 0}
                                                onChange={handleChange}
                                            />

                                        </div>

                                    </div>

                                    : <></>}

                            </div>
                        </div>
                        <button type="Submit">{nameButton}</button>

                    </form>

                </div>

                {messageDataBase ?

                    <div className={Style.message}>

                        {messageDataBase}

                        <button onClick={() => { setMessageDataBase(''); navigate('/Usuario/Get') }}> OK </button>

                    </div>

                    : <></>}
            </div>
        </div>
    );
}

export default Form;
